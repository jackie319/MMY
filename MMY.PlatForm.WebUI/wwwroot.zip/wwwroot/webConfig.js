﻿var webConfig = {
    debug: true,//是否调试
    systemName: "Element-Admin",
    urlPrefix:"/wwwroot",
    apiServerAddress: ""
};