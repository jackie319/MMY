﻿var apiConfig = {
    login: "/Account/SubmitLogin"
};